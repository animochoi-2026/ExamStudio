/* Local-only Python document composition and native HWPX packaging. */
importScripts('./runtime/pyodide.js');
let runtime, hwpxReady = false;
async function resource(path, binary = false) {
 const response = await fetch(path);
 if (!response.ok) throw Error('문서 엔진 파일을 불러오지 못했습니다: ' + path);
 return binary ? new Uint8Array(await response.arrayBuffer()) : response.text();
}
self.onmessage = async ({data}) => {
 const assets = [], format = data.format || 'docx';
 try {
  if (!['docx','hwpx'].includes(format)) throw Error('지원하지 않는 문서 형식입니다.');
  if (!runtime) {
   self.postMessage({progress:'문서 엔진을 처음 불러오는 중입니다 (약 15MB).'});
   runtime = await loadPyodide({indexURL:new URL('./runtime/',self.location.href).href});
   await runtime.loadPackage(['lxml','pillow']);
   for (const name of ['python_docx-1.2.0-py3-none-any.whl','typing_extensions-4.15.0-py3-none-any.whl']) {
    runtime.unpackArchive(await resource('./runtime/'+name,true),'zip',{extractDir:'/lib/python3.13/site-packages'});
   }
   for (const name of ['export_docx.py','word_math.py','structured_docx.py']) {
    runtime.FS.writeFile('/home/pyodide/'+name,await resource('./python/'+name));
   }
  }
  if (format === 'hwpx' && !hwpxReady) {
   for (const name of ['export_hwpx.py','hwp_native.py','hwp_compat.py']) {
    runtime.FS.writeFile('/home/pyodide/'+name,await resource('./python/'+name));
   }
   runtime.FS.mkdirTree('/home/pyodide/hwpx');
   runtime.FS.writeFile('/home/pyodide/hwpx/Skeleton.hwpx',await resource('./python/hwpx/Skeleton.hwpx',true));
   hwpxReady = true;
  }
  for (const asset of data.assets) {
   if (!/^figure-\d+-\d+\.png$/.test(asset.name)) throw Error('그림 파일 이름이 잘못되었습니다.');
   const path = '/tmp/'+asset.name;
   runtime.FS.writeFile(path,new Uint8Array(asset.bytes));
   assets.push(path);
  }
  self.postMessage({progress:format==='hwpx'?'HWPX 문단·수식·표·그림을 구성하고 참조를 검사하는 중…':'편집 가능한 문서로 변환 중…'});
  runtime.globals.set('snapshot_json',JSON.stringify(data.snapshot));
  runtime.globals.set('export_format',format);
  await runtime.runPythonAsync("import json, importlib\nengine = importlib.import_module('export_' + export_format)\nexport_result = engine.export_document(json.loads(snapshot_json), '/tmp/exam.' + export_format)");
  const bytes = runtime.FS.readFile('/tmp/exam.'+format);
  self.postMessage({bytes},[bytes.buffer]);
 } catch (e) {
  self.postMessage({error:String(e.message||e)});
 } finally {
  if (runtime) {
   for (const path of [...assets,'/tmp/exam.docx','/tmp/exam.hwpx','/tmp/exam.layout.json']) {
    if (runtime.FS.analyzePath(path).exists) runtime.FS.unlink(path);
   }
   runtime.globals.delete('snapshot_json');
  }
 }
};
