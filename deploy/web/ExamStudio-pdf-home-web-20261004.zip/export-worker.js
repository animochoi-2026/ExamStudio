/* Existing Python DOCX/OMML engine, executed locally in a browser worker. */
importScripts('./runtime/pyodide.js');
let runtime;
self.onmessage=async({data})=>{try{
 if(!runtime){self.postMessage({progress:'문서 엔진을 처음 불러오는 중입니다 (약 15MB).'});runtime=await loadPyodide({indexURL:new URL('./runtime/',self.location.href).href});self.postMessage({progress:'수식·그림 라이브러리 준비 중…'});await runtime.loadPackage(['lxml','pillow']);self.postMessage({progress:'편집 가능한 문서로 변환 중…'});
  for(const name of ['python_docx-1.2.0-py3-none-any.whl','typing_extensions-4.15.0-py3-none-any.whl'])runtime.unpackArchive(await(await fetch('./runtime/'+name)).arrayBuffer(),'zip',{extractDir:'/lib/python3.13/site-packages'});
  for(const name of ['export_docx.py','word_math.py','structured_docx.py'])runtime.FS.writeFile('/home/pyodide/'+name,await(await fetch('./python/'+name)).text());
 }
 for(const a of data.assets)runtime.FS.writeFile('/tmp/'+a.name,new Uint8Array(a.bytes));
 runtime.globals.set('snapshot_json',JSON.stringify(data.snapshot));
 await runtime.runPythonAsync("import json\nfrom export_docx import export_document\nexport_document(json.loads(snapshot_json), '/tmp/exam.docx')");
 const bytes=runtime.FS.readFile('/tmp/exam.docx');self.postMessage({bytes},[bytes.buffer]);
 for(const a of data.assets)runtime.FS.unlink('/tmp/'+a.name);
}catch(e){self.postMessage({error:String(e.message||e)});}};
