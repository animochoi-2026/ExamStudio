"""Form decorations around the existing editable document body.

The same browser-rendered form layer is embedded in DOCX and HWPX. Only the
form is an image; question paragraphs, tables and native equations are composed
by export_docx/export_hwpx exactly as before.
"""
from copy import deepcopy
from pathlib import Path
import math
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt
from docx.enum.text import WD_LINE_SPACING


def pages(snapshot):
    result = snapshot.get('paperFormPages')
    if result is None:
        return None
    if not isinstance(result, list) or not result:
        raise ValueError('시험지 폼의 페이지 정보가 없습니다.')
    if len(result) != len(snapshot.get('settings', {}).get('measuredPages', [])):
        raise ValueError('시험지 폼과 문제 페이지 수가 다릅니다.')
    for p in result:
        for key in ['topMm', 'leftMm', 'rightMm', 'bottomMm', 'gapMm', 'introMm']:
            v = p.get(key)
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 0 <= v <= 297:
                raise ValueError('시험지 폼 위치가 잘못되었습니다: '+key)
        if p['topMm']+p['bottomMm']+p['introMm'] >= 287 or p['leftMm']+p['rightMm']+p['gapMm'] >= 190:
            raise ValueError('시험지 폼의 문제 영역이 부족합니다.')
        path=Path(p['backgroundPath'])
        if not path.read_bytes().startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('시험지 폼 이미지가 PNG가 아닙니다.')
    return result


def background(paragraph, path, description, logo=None):
    inline=paragraph.add_run().add_picture(path,width=Mm(logo['widthMm'] if logo else 210),height=Mm(logo['heightMm'] if logo else 297))._inline
    anchor=OxmlElement('wp:anchor')
    for k,v in dict(distT='0',distB='0',distL='0',distR='0',simplePos='0',relativeHeight='0',behindDoc='1',locked='1',layoutInCell='0',allowOverlap='1').items():anchor.set(k,v)
    if logo:anchor.set('behindDoc','0');anchor.set('relativeHeight','251659264');anchor.set('locked','0')
    simple=OxmlElement('wp:simplePos');simple.set('x','0');simple.set('y','0');anchor.append(simple)
    for axis in ['H','V']:
        pos=OxmlElement('wp:position'+axis);pos.set('relativeFrom','page');offset=OxmlElement('wp:posOffset');offset.text=str(int(Mm(logo['xMm' if axis=='H' else 'yMm']))) if logo else '0';pos.append(offset);anchor.append(pos)
    anchor.append(deepcopy(inline.find(qn('wp:extent'))));anchor.append(OxmlElement('wp:wrapNone'))
    props=deepcopy(inline.find(qn('wp:docPr')));props.set('name','ExamPaperForm');props.set('descr',description);anchor.append(props)
    for name in ['wp:cNvGraphicFramePr','a:graphic']:
        node=inline.find(qn(name))
        if node is not None:anchor.append(deepcopy(node))
    inline.getparent().replace(inline,anchor)


def configure(section, form=None, title=''):
    section.different_first_page_header_footer=False
    section.header.is_linked_to_previous=False;section.footer.is_linked_to_previous=False
    for story in [section.header,section.footer]:
        for child in list(story._element):story._element.remove(child)
    section.header_distance=Mm(0)
    if form:
        section.top_margin=Mm(form['topMm']);section.bottom_margin=Mm(form['bottomMm'])
        section.left_margin=Mm(form['leftMm']);section.right_margin=Mm(form['rightMm'])
        paragraph=section.header.add_paragraph();paragraph.paragraph_format.space_after=Pt(0)
        background(paragraph,form['backgroundPath'],form.get('description','시험지 폼'))
        if form.get('logo'):background(paragraph,form['logo']['path'],'학원 로고',form['logo'])
    else:
        section.top_margin=Mm(20);section.bottom_margin=Mm(18);section.left_margin=Mm(15);section.right_margin=Mm(15)
        section.header_distance=Mm(8);section.header.add_paragraph(title)
    columns=section._sectPr.find(qn('w:cols'));columns.set(qn('w:num'),'2');columns.set(qn('w:sep'),'0' if form else '1');columns.set(qn('w:space'),str(round((form['gapMm'] if form else 9)*1440/25.4)))


def spacer(document, mm):
    if mm <= 0:return
    p=document.add_paragraph();f=p.paragraph_format;f.space_before=Pt(0);f.space_after=Pt(0)
    f.line_spacing_rule=WD_LINE_SPACING.EXACTLY;f.line_spacing=Mm(mm);f.keep_with_next=False;f.keep_together=False
    p.add_run(' ')
